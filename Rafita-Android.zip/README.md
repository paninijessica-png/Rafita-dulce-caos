# Rafita: Dulce Caos — prueba Android
Juego aprobado, integrado dentro de la app. Sin conexión, sin anuncios ni compras en esta versión de prueba. No pide permisos de contactos, cámara, ubicación o archivos.

Compilar con Java 17, Gradle 8.9 y Android SDK 35: `gradle :app:assembleDebug`.
La APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

GitHub desde Android: subir Rafita-Android.zip a la raíz del repositorio. Crear `.github/workflows/android.yml` con el contenido de Compilar-Rafita.yml. Después ejecutar la acción Compilar Rafita Android. Descargar el artefacto rafita-apk-prueba, extraer y abrir app-debug.apk.

Es una compilación de prueba, no la versión para publicar. Las claves de firma de distribución deben configurarse antes de publicar y conservarse para futuras actualizaciones.
