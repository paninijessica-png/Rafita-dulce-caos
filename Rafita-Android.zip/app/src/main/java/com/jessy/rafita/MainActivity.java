package com.jessy.rafita;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
public class MainActivity extends Activity {
 private WebView game;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  game=new WebView(this);
  game.setBackgroundColor(0xff230625);
  game.getSettings().setJavaScriptEnabled(true);
  game.getSettings().setDomStorageEnabled(true);
  game.getSettings().setAllowFileAccess(false);
  game.getSettings().setAllowContentAccess(false);
  game.setWebViewClient(new WebViewClient() {
   @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
    if (request.getUrl().toString().equals("https://rafita.local/index.html")) {
     try { return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html")); }
     catch (java.io.IOException error) { throw new IllegalStateException("Falta el juego", error); }
    }
    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
  });
  setContentView(game);
  game.loadUrl("https://rafita.local/index.html");
 }
 @Override protected void onPause() { super.onPause(); if(game!=null){game.onPause();game.pauseTimers();} }
 @Override protected void onResume() { super.onResume(); if(game!=null){game.resumeTimers();game.onResume();} }
 @Override protected void onDestroy() { if(game!=null)game.destroy();super.onDestroy(); }
}
